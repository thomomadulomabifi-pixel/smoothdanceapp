<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smooth Dance App</title>
<style>
body{font-family:Arial,sans-serif;margin:0;padding:0;background:#111;color:#eee;display:flex;flex-direction:column;align-items:center;}
h1{color:#ff3;background: #222;padding:15px;width:100%;text-align:center;font-size:2em;}
.dance-container{display:flex;flex-wrap:wrap;justify-content:center;gap:15px;padding:10px;}
.dance-card{background:#222;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.6);width:230px;text-align:center;padding:10px;}
.dance-cover{width:100%;border-radius:10px;}
.dance-name{font-size:1.1em;margin:8px;color:#ffd;}
.button{background:#ff3366;color:#fff;border:none;padding:10px 15px;border-radius:8px;cursor:pointer;font-size:1em;margin:5px;}
.button:disabled{background:#555;cursor:not-allowed;}
#player{width:90%;max-width:600px;margin:15px;text-align:center;}
audio{width:100%;border-radius:8px;}
#stepDisplay{font-size:1.2em;margin:10px;color:#9fc;}
#animationArea{width:100%;height:220px;border:2px solid #555;border-radius:12px;position:relative;overflow:hidden;background:#000;}
.visual{position:absolute;font-size:2.2em;opacity:0;animation:floatAnim 1s ease infinite;}
@keyframes floatAnim{0%{opacity:0;transform:translateY(160px);}35%{opacity:1;}100%{opacity:0;transform:translateY(-60px);}}
#pdfButton{margin:10px;}
.countdown{font-size:2em;color:#ff3;margin:10px;}
@media(max-width:600px){.dance-card{width:90%;}}
</style>
</head>
<body>

<h1>Smooth Dance App</h1>

<div class="dance-container" id="danceContainer"></div>

<div id="player">
  <div id="countdown" class="countdown"></div>
  <audio id="audioPlayer" controls></audio>
  <div id="stepDisplay">Select a dance to learn it here!</div>
  <div id="animationArea"></div>
  <button id="pdfButton" class="button">Download PDF Cheat Sheet</button>
</div>

<!-- jsPDF Library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

<script>
// ===== Dance Metadata =====
const dances = [
{ name:"Renegade", free:true, steps:["Clap x3","Up Down","Wave Left","Wave Right","Hit Pose","Jump Wet","Step Back","Step Forward","Punch","Hop Spin","Double Clap","Stomp","Slide Left","Slide Right","Arm Swing","Finish Pose"], song:"https://cdn.pixabay.com/download/audio/2022/03/15/audio_b8b42d79f3.mp3?filename=happy-upbeat-joyful-12657.mp3", bpm:120 },
{ name:"Savage Love", free:true, steps:["Right Step","Left Step","Body Roll","Shoulder Pop","Heel Tap","Hand Flick","Hip Roll","Slide","Jump High","Head Tilt","Chest Bounce","Wave Back","Arm Circle","Step Clap","Twist","Finish"], song:"https://cdn.pixabay.com/download/audio/2021/08/04/audio_1d6820f4d4.mp3?filename=funky-upbeat-11257.mp3", bpm:110 },
{ name:"Say So", free:false, steps:["Finger Snap","Hip Sway","Right Turn","Left Turn","Toe Tap","Wrist Flick","Step Back","Step Forward","Clap Twice","Shake it","Heel Drop","Wave Over","Spin Around","Bounce","Slide","Finish"], song:"https://cdn.pixabay.com/download/audio/2022/03/20/audio_a0f1a1f32c.mp3?filename=joyful-funky-11385.mp3", bpm:115 },
{ name:"Blinding Lights Shuffle", free:false, steps:["Shuffle Left","Shuffle Right","Arm Up","Arm Down","Jump Step","Kick Back","Body Roll","Snap","Step Slide","Turn Side","Clap Up","Double Step","Back Slide","Heel Tap","Final Pose"], song:"https://cdn.pixabay.com/download/audio/2022/03/13/audio_1c7f1db3a3.mp3?filename=upbeat-dance-11684.mp3", bpm:125 },
{ name:"Jerusalema Dance", free:false, steps:["Heel Touch","Step Side","Clap Forward","Turn Right","Step Back","Hop","Arm Sweep","Kick Forward","Slide Back","Wave Up","Cross Step","Side Kick","Shake","Step Touch","Final Pose"], song:"https://cdn.pixabay.com/download/audio/2022/03/14/audio_2db4ef92f3.mp3?filename=happy-dance-11826.mp3", bpm:118 },
{ name:"WAP Dance Routine", free:false, steps:["Hip Down","Hip Up","Step Squat","Body Twist","Clap Twice","Wave Low","Side Step","Jump Turn","Arm Wiggle","Shake Low","Turn Around","Clap High","Foot Slide","Hip Roll","Finish Move"], song:"https://cdn.pixabay.com/download/audio/2022/03/12/audio_92d7b2a7e5.mp3?filename=upbeat-groovy-11420.mp3", bpm:120 },
{ name:"Buss It Challenge", free:false, steps:["Step Down","Bounce","Low Hold","Arm Lift","Leg Swing","Body Pop","Slide Back","Clap","Close Step","Head Nod","Hip Dip","Turn Around","Step Up","Wave Big","Final Clap"], song:"https://cdn.pixabay.com/download/audio/2022/03/15/audio_c317fa89e7.mp3?filename=joyful-groovy-11788.mp3", bpm:112 },
{ name:"Toosie Slide", free:false, steps:["Slide Left","Slide Right","Heel Slide","Toe Slide","Body Pop","Clap","Arm Slide","Step Back","Spin Twice","Wave","Bounce","Turn Around","Right Touch","Left Touch","Finish"], song:"https://cdn.pixabay.com/download/audio/2022/03/11/audio_4523f55a72.mp3?filename=upbeat-funky-11500.mp3", bpm:115 }
];

// ===== Render Dance Cards =====
const container = document.getElementById("danceContainer");
dances.forEach((d,index)=>{
  const card=document.createElement("div");
  card.className="dance-card";
  card.innerHTML=`
    <div class="dance-name">${d.name}</div>
    ${d.free ? `<button class="button" onclick="startDance(${index})">FREE: Learn Now</button>` :
    `<button class="button" onclick="startDance(${index})" disabled>LOCKED - Premium</button>
     <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
       <input type="hidden" name="cmd" value="_xclick">
       <input type="hidden" name="business" value="mabifithomo015@gmail.com">
       <input type="hidden" name="item_name" value="${d.name} Premium Access">
       <input type="hidden" name="amount" value="5.00">
       <input type="hidden" name="currency_code" value="USD">
       <input type="submit" class="button" value="Buy $5 Premium">
     </form>`}
  `;
  container.appendChild(card);
});

// ===== Dance Player Logic =====
let stepTimer, visualTimer, countdownTimer;
function startDance(idx){
  const dance=dances[idx];
  const audio=document.getElementById("audioPlayer");
  const stepDisplay=document.getElementById("stepDisplay");
  const animArea=document.getElementById("animationArea");
  const countdownDisplay=document.getElementById("countdown");

  clearInterval(stepTimer);
  clearInterval(visualTimer);
  clearInterval(countdownTimer);
  stepDisplay.textContent="";
  animArea.innerHTML="";
  countdownDisplay.textContent="";

  // Countdown 3-2-1
  let count=3;
  countdownDisplay.textContent=count;
  countdownTimer=setInterval(()=>{
    count--;
    if(count>0) countdownDisplay.textContent=count;
    else { clearInterval(countdownTimer); countdownDisplay.textContent="Go!"; startDanceSteps(dance); }
  },1000);
}

function startDanceSteps(dance){
  const audio=document.getElementById("audioPlayer");
  const stepDisplay=document.getElementById("stepDisplay");
  const animArea=document.getElementById("animationArea");

  audio.src=dance.song;
  audio.play();

  let i=0;
  const intervalMs = 60000 / dance.bpm; // step per beat
  stepTimer=setInterval(()=>{
    if(i>=dance.steps.length){ clearInterval(stepTimer); clearInterval(visualTimer); stepDisplay.textContent="Dance Complete!"; return; }
    stepDisplay.textContent=dance.steps[i];
    i++;
  }, intervalMs);

  visualTimer=setInterval(()=>{
    const v=document.createElement("div");
    const icons=["⬆","⬇","⬅","➡","↗","↘","✨","🔥"];
    v.className="visual";
    v.textContent=icons[Math.floor(Math.random()*icons.length)];
    v.style.left=Math.random()*80+"%";
    animArea.appendChild(v);
    setTimeout(()=>v.remove(),intervalMs);
  }, intervalMs/2);
}

document.getElementById("audioPlayer").addEventListener("pause",()=>{
  clearInterval(stepTimer); clearInterval(visualTimer);
});

// ===== PDF Cheat Sheet =====
document.getElementById("pdfButton").addEventListener("click",()=>{
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  let y=10;
  doc.setFontSize(16);
  doc.text("Smooth Dance App - Cheat Sheet",10,y);
  y+=10;
  dances.forEach(d=>{
    doc.setFontSize(14);
    doc.text(d.name,10,y);
    y+=6;
    doc.setFontSize(12);
    d.steps.forEach((s,i)=>{
      doc.text(`${i+1}. ${s}`,12,y);
      y+=5;
      if(y>280){ doc.addPage(); y=10; }
    });
    y+=5;
  });
  doc.save("Smooth_Dance_App_CheatSheet.pdf");
});
</script>

</body>
</html>